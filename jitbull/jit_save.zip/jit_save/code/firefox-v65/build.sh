#!/bin/bash

cd mozilla-unified
rm -rf ~/.mozbuild
./mach clobber
./mach build
cd ..
