#!/bin/bash

curl https://hg.mozilla.org/mozilla-central/raw-file/default/python/mozboot/bin/bootstrap.py -O
python3 bootstrap.py --no-interactive --application-choice browser
rm -f bootstrap.py
cd mozilla-unified
hg update FIREFOX_65_0_RELEASE
hg import --no-commit ../spidersecurity.diff
#echo "ac_add_options --enable-debug" >> mozconfig
echo "ac_add_options --enable-bigint" >> mozconfig
echo "ac_add_options --enable-ion  # because enabling big int disables ion by default, cf moz.configure line 127" >> mozconfig
#echo "ac_add_options --enable-jitspew" >> mozconfig
cd ..
