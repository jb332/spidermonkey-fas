#!/bin/bash

cd mozilla-unified
./mach run
cd ..
