#!/bin/bash

PROJECT_HOME_DIR=/home/jb/Documents/research/projects/jit/code
export CACHEIR_LOGS=1
export IONFLAGS=logs,scripts,mir,bl-all,aborts
#export ION_SPEW_FILENAME=/tmp/ion_log.txt
#export ION_SPEW_BY_PID=
export ION_DEP_GRAPH_BY_PID=
export ION_SECURE_MODE=
export ION_EXPLOIT_DB_PATH="${PROJECT_HOME_DIR}/exploits_db"
export ION_LOG_FUNC_CALLS=1
export ION_LOG_TO_FILES=1

PATCHED=
FILE=""
CVE=""
VAR=""
ION=1
THREADS=1

if [ $# -eq 0 ]
then
   set -- "--help"
fi

while [ $# -gt 0 ]
do
   if [ $1 == "--help" ]
   then
      echo "Usage :"
      echo ""
      echo "\"./test_exec.sh [--safe] [--log <log_level>] --cve <cve_name> [--var <variant_nr>]\""
      echo "  or"
      echo "\"./test_exec.sh [--safe] [--log <log_level>] --file <js_file>\""
      echo "  or"
      echo "\"./test_exec.sh [--patched] --cve <cve_name> [--var <variant_nr>]\""
      echo "  or"
      echo "\"./test_exec.sh [--patched] --file <js_file>\""
      exit 0
   elif [ $1 == "--safe" ]
   then
      export ION_SECURE_MODE=1
   elif [ $1 == "--patched" ]
   then
      PATCHED=1
   elif [ $1 == "--log" ]
   then
      shift
      export ION_LOG_FUNC_CALLS=$1
   elif [ $1 == "--file" ]
   then
      shift
      FILE=$1
   elif [ $1 == "--cve" ]
   then
      shift
      CVE=$1
   elif [ $1 == "--var" ]
   then
      shift
      VAR=$1
   elif [ $1 == "--no-ion" ]
   then
      ION=0
   elif [ $1 == "--single-threaded-ion" ]
   then
      THREADS=0
   else
      echo "Error : Unknown parameter \"$1\""
      exit 1
   fi
   shift
done


if [ -n "$PATCHED" ] && [ -n "$ION_SECURE_MODE" ]
then
   echo "Error : --safe and --patched options are mutually exclusive. JS files are either run on firefox version 65 using the safe mode or they are run on the last firefox version that is immune to known vulnerabilities."
   exit 1
fi

if [ -n "$ION_SECURE_MODE" ] && [ $ION -eq 0 ]
then
   echo "Error : --safe and --no-ion options are mutually exclusive. The Ion compiler needs to be enabled in order to enable the secure mode."
   exit 1
fi

if [ $THREADS -eq 0 ] && [ $ION -eq 0 ]
then
   echo "Error : --single-threaded-ion and --no-ion options are mutually exclusive. The Ion compiler needs to be enabled in order to disable multi-threading during compilation."
   exit 1
fi

if [ -z "$FILE" ] && [ -z "$CVE" ]
then
   echo "Error : Cannot run JS file. No file path or cve name provided."
   exit 1
fi

if [ -n "$FILE" ] && ([ -n "$CVE" ] || [ -n "$VAR" ])
then
   echo "Error : --file and --cve / --var options are mutually exclusive. JS files are either loaded from the database from a cve name and a variant (1 by default) or they are loaded given a specific path."
   exit 1
fi

if [ -n "$CVE" ] && [ -z "$VAR" ]
then
   VAR=1
fi

if [ -n "$CVE" ]
then
   JS_FILE="${ION_EXPLOIT_DB_PATH}/exploits/${CVE}/variant_${VAR}/exploit.js"
   echo $JS_FILE
else
   if [[ "$FILE" = /* ]]
   then
      JS_FILE=$FILE
   else
      JS_FILE="${PROJECT_HOME_DIR}/${FILE}"
   fi
fi

if [ -n "$PATCHED" ]
then
   FIREFOX_VERSION="spidermonkey-latest"
else
   FIREFOX_VERSION="spidermonkey-v65"
fi

cd "${FIREFOX_VERSION}/mozilla-unified/obj-x86_64-pc-linux-gnu/dist/bin"
#cat $JS_FILE

CMD="./js"

if [ $ION -eq 0 ]
then
   CMD="${CMD} --no-ion"
fi

if [ $THREADS -eq 0 ]
then
   CMD="${CMD} --ion-offthread-compile=off"
fi

CMD="${CMD} ${JS_FILE}"
echo $CMD
$CMD

cd ../../../../..

