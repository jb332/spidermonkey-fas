#!/bin/bash

curl https://hg.mozilla.org/mozilla-central/raw-file/default/python/mozboot/bin/bootstrap.py -O
python3 bootstrap.py --no-interactive --application-choice js
rm -f bootstrap.py
cd mozilla-unified
#echo "ac_add_options --enable-debug" >> mozconfig
echo "ac_add_options --enable-jit" >> mozconfig
#echo "ac_add_options --enable-jitspew" >> mozconfig
rm -rf ~/.mozbuild
./mach clobber && ./mach build
cd ..
