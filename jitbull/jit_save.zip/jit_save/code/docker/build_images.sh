#!/bin/bash

docker rmi spidermonkey_v65
docker rmi spidermonkey_last
docker build --tag spidermonkey_v65 --file v65_dockerfile .
docker build --tag spidermonkey_last --file last_dockerfile .

