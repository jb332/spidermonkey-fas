docker exec -it spidermonkey_last_container sudo -H -u jb /bin/bash -c 'cd $HOME ; /bin/bash'

