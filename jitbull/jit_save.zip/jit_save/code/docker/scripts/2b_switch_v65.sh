#!/bin/bash

cd /home/jb/mozilla-unified
hg update FIREFOX_65_0_RELEASE
hg import --no-commit ../patch/spidersecurity.diff
echo "ac_add_options --enable-bigint" >> mozconfig
echo "ac_add_options --enable-ion  # because enabling big int disables ion by default, cf moz.configure line 127" >> mozconfig

