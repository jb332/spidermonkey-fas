#!/bin/bash

groupadd -g 1001 jb
useradd -u 1001 -g 1001 --create-home jb

