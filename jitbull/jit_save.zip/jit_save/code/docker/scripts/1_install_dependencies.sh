#!/bin/bash

apt-get update -yq
apt-get install -yq apt-utils
echo 'debconf debconf/frontend select Noninteractive' | debconf-set-selections
apt-get install -yq sudo graphviz git vim curl autoconf2.13 python2.7 python2.7-dev python3-dev python3-pip libgmp3-dev
python3 -m pip install mercurial
rm -f /usr/bin/python 2> /dev/null
ln -n /usr/bin/python2.7 /usr/bin/python

