#!/bin/bash

cd /home/jb
curl https://hg.mozilla.org/mozilla-central/raw-file/default/python/mozboot/bin/bootstrap.py -O
python3 bootstrap.py --no-interactive --application-choice js
rm -f bootstrap.py
cd mozilla-unified

