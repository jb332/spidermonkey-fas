#!/bin/bash

export SHELL=/bin/bash
cd /home/jb/mozilla-unified
rm -rf ~/.mozbuild
./mach clobber
./mach build

