#!/bin/bash

cd /home/jb
chown -R jb mozilla-unified
chgrp -R jb mozilla-unified
chown -R jb scripts
chgrp -R jb scripts

