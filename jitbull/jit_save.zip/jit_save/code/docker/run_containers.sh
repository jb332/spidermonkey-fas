#!/bin/bash

docker compose up --detach

