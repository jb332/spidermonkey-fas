docker exec -it spidermonkey_v65_container sudo -H -u jb /bin/bash -c 'cd $HOME ; /bin/bash'

