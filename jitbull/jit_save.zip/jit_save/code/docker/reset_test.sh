#!/bin/bash

docker kill spidermonkey_test_container
docker rm spidermonkey_test_container
docker rmi spidermonkey_test
docker build --tag spidermonkey_test --file test_dockerfile .
docker create --name spidermonkey_test_container --volume /home/jb/Documents/research/projects/jit/code/exploits_db:/home/jb/exploits_db spidermonkey_test
docker start spidermonkey_test_container
docker exec -it spidermonkey_test_container /bin/bash

