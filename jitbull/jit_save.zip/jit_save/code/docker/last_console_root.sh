docker exec -it spidermonkey_last_container /bin/bash

