#!/bin/bash

WORK_DIR="/home/jb/Documents/research/projects/jit/code"
DB_DIR="${WORK_DIR}/exploits_db"
EXPLOITS_FILES=$(find "${DB_DIR}/exploits/" -type f -name exploit.js)

function log_to_file() {
  echo -e $1 >> "${WORK_DIR}/build_diff_database_log.txt"
}

export ION_SECURE_MODE=1
export ION_DB_BUILDING=1
export ION_EXPLOIT_DB_PATH=$DB_DIR

#rm build_diff_database_log.txt
#touch build_diff_database_log.txt

CPT=0

for EXPLOIT_FILE in $EXPLOITS_FILES
do
  ((CPT++))
  >&2 echo -e "\n\n\n\n\n"
  #log_to_file "iteration n°${CPT}"
  EXPLOIT_DIR=$(dirname $EXPLOIT_FILE)
  CVE=$(basename $(dirname $EXPLOIT_DIR))
  VARIANT=$(basename $EXPLOIT_DIR)
  export ION_CVE_YEAR=$(echo $CVE | awk -F - '{print $2}')
  export ION_CVE_ID=$(echo $CVE | awk -F - '{print $3}')
  export ION_VARIANT_NR=$(echo $VARIANT | awk -F _ '{print $2}')
  
  >&2 echo -e "${EXPLOIT_DIR} :\n"
  
  EXPLOIT_SCRIPTS_DIFFS_DIR_PATH="${DB_DIR}/diffs/${CVE}/${VARIANT}"
  if [ -d $EXPLOIT_SCRIPTS_DIFFS_DIR_PATH ]
  then
    rm -f $EXPLOIT_SCRIPTS_DIFFS_DIR_PATH/*
  else
    mkdir -p $EXPLOIT_SCRIPTS_DIFFS_DIR_PATH
  fi
  cd $EXPLOIT_DIR
  "${WORK_DIR}/spidermonkey-v65/mozilla-unified/obj-x86_64-pc-linux-gnu/dist/bin/js" exploit.js &
  SPIDERMONKEY_PID=$!
  sleep 1
  if [ "$(ps -p $SPIDERMONKEY_PID | wc -l)" -gt 1 ]
  then
    kill -9 $SPIDERMONKEY_PID
  fi
  #log_to_file "cd ${EXPLOIT_DIR}"
  #log_to_file "${WORK_DIR}/spidermonkey-v65/mozilla-unified/obj-x86_64-pc-linux-gnu/dist/bin/js exploit.js"
done

