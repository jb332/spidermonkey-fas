function f1(y) {
   return y + 1;
}

x = 42;
for (let i = 0; i < 1000000000; i++)
{
   x = f1(x);
}
