function f(i) {
    let x = i * 3 +1;
    let arr = [1, 2, 5];
    arr.push(x);
    return arr;
}

let obj_list = [];
for (let i = 0; i < 0x100000; i++) {
    let a = {};
    a.tab = f(42);
    obj_list.push(a);
}
