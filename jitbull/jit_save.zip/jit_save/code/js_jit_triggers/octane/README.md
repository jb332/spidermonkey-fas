# Octane

Octane 2.0 is a benchmark that measures a JavaScript engine’s performance by running a suite of tests representative of certain use cases in JavaScript applications.

Please note that [Octane is retired](https://v8project.blogspot.com/2017/04/retiring-octane.html) and no longer maintained.

[Run Octane 2 now!](http://chromium.github.io/octane/)

For more information, check out the [homepage](https://developers.google.com/octane/), [benchmark reference](https://developers.google.com/octane/benchmark), or [FAQ](https://developers.google.com/octane/faq).
