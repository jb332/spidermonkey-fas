var base_dir = '/home/jb/Documents/research/projects/jit/code/js_jit_triggers/octane/src/';
load(base_dir + 'base.js');
load(base_dir + 'typescript.js');
load(base_dir + 'typescript-input.js');
load(base_dir + 'typescript-compiler.js');
load(base_dir + 'run.js');
