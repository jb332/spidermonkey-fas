var base_dir = '/home/jb/Documents/research/projects/jit/code/js_jit_triggers/octane/src/';
load(base_dir + 'base.js');
load(base_dir + 'splay.js');
load(base_dir + 'run.js');
