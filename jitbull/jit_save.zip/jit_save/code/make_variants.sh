#!/bin/bash

EXPLOIT_PATHS=$(find exploits_db/exploits/ -type f -name exploit.js | grep variant_1)

for EXPLOIT_PATH in $EXPLOIT_PATHS
do
   VARIANT_1_DIR_PATH=$(dirname $EXPLOIT_PATH)
   CVE_DIR_PATH=$(dirname $VARIANT_1_DIR_PATH)
   VARIANT_1_DIR_NAME=$(basename $VARIANT_1_DIR_PATH)
   if [ "$(echo $VARIANT_1_DIR_NAME | cut -c1-9)" = "variant_1" ]
   then
      VARIANT_EXTENSION=$(echo $VARIANT_1_DIR_NAME | cut -c10-)
      
      # variant 2 : rename variables
      VARIANT_2_DIR_PATH="${CVE_DIR_PATH}/variant_2${VARIANT_EXTENSION}"
      mkdir -p "${CVE_DIR_PATH}/variant_2${VARIANT_EXTENSION}"
      terser "${VARIANT_1_DIR_PATH}/exploit.js" --mangle --toplevel --format 'beautify=true' --output "${VARIANT_2_DIR_PATH}/exploit.js"
      
      # variant 3 : minification
      VARIANT_3_DIR_PATH="${CVE_DIR_PATH}/variant_3${VARIANT_EXTENSION}"
      mkdir -p "${CVE_DIR_PATH}/variant_3${VARIANT_EXTENSION}"
      terser "${VARIANT_1_DIR_PATH}/exploit.js" --compress 'unused=false' --mangle --toplevel --format 'beautify=true' --output "${VARIANT_3_DIR_PATH}/exploit.js"
      
      # [manual] variant 4 : intertwine independent instructions
      # [manual] variant 5 : create subfunctions
      # [manual] variant 6 : try adding useless instructions
   fi
done

