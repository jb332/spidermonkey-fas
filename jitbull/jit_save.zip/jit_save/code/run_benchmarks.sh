#!/bin/bash

./run_benchmark.sh js_jit_triggers/box2d.js
./run_benchmark.sh js_jit_triggers/crypto.js
./run_benchmark.sh js_jit_triggers/deltablue.js
./run_benchmark.sh js_jit_triggers/earley-boyer.js
./run_benchmark.sh js_jit_triggers/gbemu.js
./run_benchmark.sh js_jit_triggers/mandreel.js
./run_benchmark.sh js_jit_triggers/navier-stokes.js
./run_benchmark.sh js_jit_triggers/pdfjs.js
./run_benchmark.sh js_jit_triggers/raytrace.js
./run_benchmark.sh js_jit_triggers/regexp.js
./run_benchmark.sh js_jit_triggers/richards.js
./run_benchmark.sh js_jit_triggers/splay.js
./run_benchmark.sh js_jit_triggers/typescript.js
./run_benchmark.sh js_jit_triggers/random_code_1.js
./run_benchmark.sh js_jit_triggers/test_jit.js

