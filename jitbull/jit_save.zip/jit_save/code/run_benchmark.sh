#!/bin/bash

BENCH_NAME=$(basename $1 .js)
OUTPUT_FILE="benchmarks_output/benchmark_output_${BENCH_NAME}.txt"

echo "Running: ./run_script.sh --no-ion --file ${1}"
./run_script.sh --no-ion --file $1 > $OUTPUT_FILE
echo "" >> $OUTPUT_FILE

echo "Running: ./run_script.sh --single-threaded-ion --file ${1}"
./run_script.sh --single-threaded-ion --file $1 >> $OUTPUT_FILE
echo "" >> $OUTPUT_FILE

echo "Running: ./run_script.sh --safe --single-threaded-ion --file ${1}"
./run_script.sh --safe --single-threaded-ion --file $1 >> $OUTPUT_FILE
echo "" >> $OUTPUT_FILE

echo "Running: ./run_script.sh --file ${1}"
./run_script.sh --file $1 >> $OUTPUT_FILE
echo "" >> $OUTPUT_FILE

echo "Running: ./run_script.sh --safe --file ${1}"
./run_script.sh --safe --file $1 >> $OUTPUT_FILE
echo "" >> $OUTPUT_FILE
