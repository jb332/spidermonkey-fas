#!/bin/bash

function match_location {
   if [ -f $1 ]
   then
      test -n "$(cat $1 | head -n 1 | grep $2)"
   else
      false
   fi
}

BLANK_MODE=0
DIFF_PATHS=$(find exploits_db/diffs/ -type f -name "script_diff_*.txt")

for DIFF_PATH in $DIFF_PATHS
do
   # remove diffs that match the whole script for all cves
   if match_location $DIFF_PATH "exploit.js:1:0"
   then
      echo "any cve / full script"
      if [ $BLANK_MODE -eq 1 ]
      then
         echo "rm -f $DIFF_PATH"
      else
         rm -f $DIFF_PATH
      fi
   fi
   
   # remove diffs that match self-hosted functions for all cves
   if match_location $DIFF_PATH "self-hosted"
   then
      echo "any cve / self-hosted function"
      if [ $BLANK_MODE -eq 1 ]
      then
         echo "rm -f $DIFF_PATH"
      else
         rm -f $DIFF_PATH
      fi
   fi
   
   CVE_NAME=$(basename $(dirname $(dirname $DIFF_PATH)))
   VAR_NAME=$(basename $(dirname $DIFF_PATH))
   
   # remove diffs that match the "buf[7].func" function in cve-2019-11707
   if [ "$CVE_NAME" == "cve-2019-11707" ]
   then
      if [ "$VAR_NAME" == "variant_1" ] && match_location $DIFF_PATH "exploit.js:325:27"
      then
         echo "cve-2019-11707 variant 1 / exploit.js:325:27"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_2" ] && match_location $DIFF_PATH "exploit.js:240:24"
      then
         echo "cve-2019-11707 variant 2 / exploit.js:240:24"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_3" ] && match_location $DIFF_PATH "exploit.js:107:74"
      then
         echo "cve-2019-11707 variant 3 / exploit.js:107:74"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_5" ] && match_location $DIFF_PATH "exploit.js:329:27"
      then
         echo "cve-2019-11707 variant 5 / exploit.js:329:27"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      fi
   fi
   
   if [ "$CVE_NAME" == "cve-2019-9810" ]
   then
      # remove diffs that match the "obj[Symbol.species]" function in cve-2019-9810
      if [ "$VAR_NAME" == "variant_1" ] && match_location $DIFF_PATH "exploit.js:21:30"
      then
         echo "cve-2019-9810 variant 1 / exploit.js:21:30"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_2" ] && match_location $DIFF_PATH "exploit.js:23:28"
      then
         echo "cve-2019-9810 variant 2 / exploit.js:23:28"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_3" ] && match_location $DIFF_PATH "exploit.js:16:28"
      then
         echo "cve-2019-9810 variant 3 / exploit.js:16:28"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_5" ] && match_location $DIFF_PATH "exploit.js:21:30"
      then
         echo "cve-2019-9810 variant 5 / exploit.js:21:30"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      fi
      # remove diffs that match the "gc" function in cve-2019-9810
      if [ "$VAR_NAME" == "variant_1" ] && match_location $DIFF_PATH "exploit.js:5:11"
      then
         echo "cve-2019-9810 variant 1 / exploit.js:5:11"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_2" ] && match_location $DIFF_PATH "exploit.js:7:10"
      then
         echo "cve-2019-9810 variant 2 / exploit.js:7:10"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_3" ] && match_location $DIFF_PATH "exploit.js:3:10"
      then
         echo "cve-2019-9810 variant 3 / exploit.js:3:10"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      elif [ "$VAR_NAME" == "variant_5" ] && match_location $DIFF_PATH "exploit.js:5:11"
      then
         echo "cve-2019-9810 variant 5 / exploit.js:5:11"
         if [ $BLANK_MODE -eq 1 ]
         then
            echo "rm -f $DIFF_PATH"
         else
            rm -f $DIFF_PATH
         fi
      fi
   fi
done

